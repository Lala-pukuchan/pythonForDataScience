from setuptools import setup, find_packages

setup(
    name='ft_package',
    version='0.0.1',
    packages=find_packages(),
    install_requires=[],
    author='eagle',
    author_email='eagle@42.fr',
    description='A sample test package',
    license='MIT',
    url='https://github.com/eagle/ft_package',
)
