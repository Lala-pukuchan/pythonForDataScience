```
python3 setup.py sdist bdist_wheel
pip3 install ./dist/ft_package-0.0.1.tar.gz
pip3 install ./dist/ft_package-0.0.1-py3-none-any.whl
```